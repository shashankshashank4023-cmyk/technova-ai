# TechNova AI: Android app (Java)

A small native Android app (Java) that opens your deployed TechNova AI site full screen. It has its own icon, a progress bar, back-button handling, an offline message, and keeps your chats saved.

The Spring Boot backend must be deployed first, because this app only displays the website.

## Build it in Android Studio

1. Install [Android Studio](https://developer.android.com/studio).
2. **New Project → Empty Views Activity.** Name: `TechNova AI`. Package name: `com.technova.ai`. Language: **Java**. Minimum SDK: API 24 or higher.
3. Let Gradle finish syncing.
4. In the Project view (Android → Project Files), **delete** these template files and folders under `app/src/main`:
   - `java/com/technova/ai/MainActivity.java`
   - `res/layout/activity_main.xml`
   - all `res/mipmap-*` folders (including `mipmap-anydpi-v26`)
   - `res/values/themes.xml` and `res/values/strings.xml` (also `res/values-night` if present)
5. Copy this folder's `app/src/main/` contents over your project's `app/src/main/` (the `java`, `res` folders and `AndroidManifest.xml`).
6. Open `MainActivity.java` and set `APP_URL` to your deployed HTTPS URL.
7. Run it on a phone or emulator (the green play button).

## Make an APK to share

**Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows where the `.apk` file is. People can install it on their phone (they must allow installs from unknown sources).

## Publish on Google Play

1. Create a [Play Console](https://play.google.com/console) account (one-time fee).
2. **Build → Generate Signed Bundle / APK → Android App Bundle**, create and **back up your keystore** (you need it for every update).
3. Upload the `.aab`, add the 512×512 icon (`play-store-icon-512.png`), screenshots and a privacy policy, then submit for review.

Google can reject apps that are only a wrapped website. Make sure the app is useful on its own (the topics, saved chats and AI answers help), and describe it clearly.

## Faster alternative (no Android Studio)

Your site is already an installable web app (PWA). Go to [pwabuilder.com](https://www.pwabuilder.com), enter your deployed URL, and it can generate an Android package for the Play Store.
