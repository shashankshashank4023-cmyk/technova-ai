# TechNova AI (Java)

A multi-topic AI assistant with a **Java 17 / Spring Boot 3** backend. Pick a topic (Study, Tech, Politics, Banking, Stocks, Sports, Movies or General) and chat. Each topic adds focused guidance to the system prompt, so answers match the subject.

## Features

- Spring Boot REST API (`POST /api/chat`, `GET /api/topics`)
- 8 topics, each with its own prompt guidance and example question
- Separate conversation per topic, saved in the browser
- Input validation (Bean Validation), central error handling, per-IP rate limiting
- API key stays on the server, never in the browser
- Optional live web search for news, sports scores and prices (see below)
- Installable on phones like an app (PWA): home-screen icon, full-screen, no browser bar
- Dockerfile for easy deployment

## Tech stack

Java 17 · Spring Boot 3.3 · Spring Web (`RestClient`) · Bean Validation · JUnit 5 · Maven · plain HTML/CSS/JS frontend served by Spring

## Project structure

```
technova-ai-java/
├── pom.xml
├── Dockerfile
├── .env.example
├── src/main/java/com/technova/ai/
│   ├── TechNovaApplication.java
│   ├── controller/ChatController.java      # REST endpoints
│   ├── service/ChatService.java            # builds prompt + cleans history
│   ├── service/ClaudeClient.java           # calls the Anthropic Messages API
│   ├── model/ (Topic, ChatRequest, ChatResponse)
│   ├── config/RateLimitFilter.java         # per-IP limit on /api/chat
│   └── exception/ (ApiException, GlobalExceptionHandler)
├── src/main/resources/
│   ├── application.properties
│   └── static/index.html                   # frontend
└── src/test/java/com/technova/ai/TopicTest.java
```

## Run locally

You need Java 17+ and Maven.

```bash
export ANTHROPIC_API_KEY=your-key        # Windows PowerShell: $env:ANTHROPIC_API_KEY="your-key"
mvn spring-boot:run
```

Open http://localhost:8080. Run the tests with `mvn test`.

## API

```bash
curl http://localhost:8080/api/topics

curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"What does the P/E ratio tell an investor?","topic":"stocks","history":[]}'
```

Response: `{"reply":"...","topic":"stocks"}`. Errors return `{"error":"..."}` with status 400, 429, 500 or 502.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | none (required) | Your Anthropic API key |
| `ANTHROPIC_MODEL` | `claude-sonnet-5-5` | Model to use |
| `WEB_SEARCH_ENABLED` | `false` | Lets the model search the web for live info |
| `RATE_LIMIT_PER_MINUTE` | `20` | Requests per IP per minute on `/api/chat` |
| `PORT` | `8080` | Server port |

## Live information (news, scores, prices)

A language model does not know today's stock prices, match scores or breaking news on its own. Set `WEB_SEARCH_ENABLED=true` to let the model use Anthropic's web search tool. It must be enabled for your organization in the Anthropic Console, and searches may add cost. Without it, the assistant is instructed to say when it cannot verify current information.

## Deploy

Use any host that runs Docker, such as Render or Railway:

1. Push this repo to GitHub.
2. Create a new Web Service from the repo (it detects the `Dockerfile`).
3. Add `ANTHROPIC_API_KEY` as an environment variable, then deploy.

Set a monthly spend limit in the Anthropic Console, since the public endpoint uses your credits.

## Use it like a mobile app (PWA)

After you deploy over HTTPS, users can install TechNova AI from the browser, with no app store:

- **Android (Chrome):** open the site, tap the menu (⋮), then **Install app** or **Add to Home screen**.
- **iPhone (Safari):** open the site, tap **Share**, then **Add to Home Screen**.

It then opens full screen with its own icon. The app shell is cached so it starts instantly, but chat needs an internet connection. (Installing requires HTTPS, which Render and Railway provide.)

## Important notes

- Banking and stocks answers are general information, not financial advice.
- Politics answers are meant to be balanced and factual.
- The rate limiter is in-memory, so it works for one instance. Use Redis for several.
- Conversations live in the browser's `localStorage`, not in a database.

## Ideas to extend

- Token streaming (Server-Sent Events), user login (Spring Security), PostgreSQL chat history, document upload with embeddings, Redis rate limiting

## License

MIT
