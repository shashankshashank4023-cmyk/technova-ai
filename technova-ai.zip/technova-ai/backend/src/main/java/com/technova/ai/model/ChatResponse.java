package com.technova.ai.model;

public record ChatResponse(String reply, String topic) {
}
