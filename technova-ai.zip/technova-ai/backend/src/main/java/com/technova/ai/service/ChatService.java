package com.technova.ai.service;

import com.technova.ai.model.ChatRequest;
import com.technova.ai.model.ChatResponse;
import com.technova.ai.model.Topic;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class ChatService {
    private final ClaudeClient claude;

    public ChatService(ClaudeClient claude) {
        this.claude = claude;
    }

    public ChatResponse chat(ChatRequest req) {
        Topic topic = Topic.from(req.topic());
        List<Map<String, String>> messages = buildMessages(req);
        String reply = claude.complete(buildSystemPrompt(topic), messages);
        return new ChatResponse(reply, topic.id());
    }

    String buildSystemPrompt(Topic topic) {
        return "You are TechNova AI, a helpful assistant for study, technology, politics, banking, stocks, sports and movies. "
                + "Today's date is " + LocalDate.now() + ". "
                + "Answer directly and concisely, using short paragraphs or \"- \" bullets, and fenced code blocks for code. "
                + "If you are unsure, or the information may be out of date, say so instead of guessing. "
                + "Never invent facts, statistics, prices, scores or quotes. "
                + "Topic focus: " + topic.label() + ". " + topic.guidance();
    }

    /** The API needs messages that start with "user" and alternate roles, so clean the history defensively. */
    List<Map<String, String>> buildMessages(ChatRequest req) {
        List<Map<String, String>> messages = new ArrayList<>();
        if (req.history() != null) {
            for (ChatRequest.Turn turn : req.history()) {
                String last = messages.isEmpty() ? null : messages.get(messages.size() - 1).get("role");
                if (messages.isEmpty() && !"user".equals(turn.role())) continue;
                if (turn.role().equals(last)) continue;
                messages.add(Map.of("role", turn.role(), "content", turn.content()));
            }
        }
        if (!messages.isEmpty() && "user".equals(messages.get(messages.size() - 1).get("role"))) {
            messages.remove(messages.size() - 1);
        }
        messages.add(Map.of("role", "user", "content", req.message()));
        return messages;
    }
}
