package com.technova.ai.model;

/** Each topic adds focused guidance to the system prompt. */
public enum Topic {
    GENERAL("General", "Answer any general question helpfully.",
            "What are some good habits for learning faster?"),
    STUDY("Study", "Act as a patient tutor. Explain step by step with simple examples, then give a short summary or practice question when useful.",
            "Explain photosynthesis in simple words"),
    TECH("Tech", "Cover programming, software, AI and gadgets. Use fenced code blocks for code and mention that versions and best practices change.",
            "REST vs GraphQL: when should I use which?"),
    POLITICS("Politics", "Be factual and balanced. Present the main viewpoints fairly, do not give personal opinions on contested issues, and note that situations change quickly.",
            "How does a parliamentary system work?"),
    BANKING("Banking", "Explain banking and personal finance concepts (accounts, loans, EMI, interest, cards, UPI) clearly. This is general information, not financial advice, and rules vary by country and bank, so suggest confirming with the bank.",
            "How is a home loan EMI calculated?"),
    STOCKS("Stocks", "Explain markets, company fundamentals and investing concepts. You cannot see live prices unless web search is available, so never state current prices from memory. This is education, not investment advice, and investing carries risk.",
            "What does the P/E ratio tell an investor?"),
    SPORTS("Sports", "Cover rules, history, players and statistics. Live scores and very recent results are only reliable if web search is available, so say when you cannot verify them.",
            "Explain the offside rule in football"),
    MOVIES("Movies", "Discuss films and shows: plots, cast, themes and recommendations. Warn before spoilers. Recent releases may be unknown unless web search is available.",
            "Suggest sci-fi movies like Interstellar");

    private final String label;
    private final String guidance;
    private final String example;

    Topic(String label, String guidance, String example) {
        this.label = label;
        this.guidance = guidance;
        this.example = example;
    }

    public String id() { return name().toLowerCase(); }
    public String label() { return label; }
    public String guidance() { return guidance; }
    public String example() { return example; }

    /** Unknown or missing topics fall back to GENERAL. */
    public static Topic from(String value) {
        if (value == null || value.isBlank()) return GENERAL;
        try {
            return Topic.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return GENERAL;
        }
    }
}
