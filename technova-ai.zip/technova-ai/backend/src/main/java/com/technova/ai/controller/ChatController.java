package com.technova.ai.controller;

import com.technova.ai.model.ChatRequest;
import com.technova.ai.model.ChatResponse;
import com.technova.ai.model.Topic;
import com.technova.ai.service.ChatService;
import jakarta.validation.Valid;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ChatController {
    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @GetMapping("/topics")
    public List<Map<String, String>> topics() {
        return Arrays.stream(Topic.values())
                .map(t -> Map.of("id", t.id(), "label", t.label(), "example", t.example()))
                .toList();
    }

    @PostMapping("/chat")
    public ChatResponse chat(@Valid @RequestBody ChatRequest request) {
        return chatService.chat(request);
    }
}
