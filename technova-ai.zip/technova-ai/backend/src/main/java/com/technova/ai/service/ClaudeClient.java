package com.technova.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.technova.ai.exception.ApiException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

/** Thin wrapper around the Anthropic Messages API. The API key never leaves the server. */
@Service
public class ClaudeClient {
    private static final Logger log = LoggerFactory.getLogger(ClaudeClient.class);

    private final RestClient http;
    private final String apiKey;
    private final String model;
    private final int maxTokens;
    private final boolean webSearch;

    public ClaudeClient(RestClient.Builder builder,
                        @Value("${anthropic.api-key}") String apiKey,
                        @Value("${anthropic.model}") String model,
                        @Value("${anthropic.max-tokens}") int maxTokens,
                        @Value("${anthropic.web-search}") boolean webSearch) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(10_000);
        factory.setReadTimeout(60_000);
        this.http = builder
                .requestFactory(factory)
                .baseUrl("https://api.anthropic.com")
                .defaultHeader("x-api-key", apiKey)
                .defaultHeader("anthropic-version", "2023-06-01")
                .build();
        this.apiKey = apiKey;
        this.model = model;
        this.maxTokens = maxTokens;
        this.webSearch = webSearch;
    }

    public String complete(String system, List<Map<String, String>> messages) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new ApiException(500, "Server is missing ANTHROPIC_API_KEY.");
        }

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("max_tokens", maxTokens);
        body.put("system", system);
        body.put("messages", messages);
        if (webSearch) {
            body.put("tools", List.of(Map.of(
                    "type", "web_search_20250305",
                    "name", "web_search",
                    "max_uses", 3)));
        }

        try {
            JsonNode res = http.post()
                    .uri("/v1/messages")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(body)
                    .retrieve()
                    .body(JsonNode.class);

            StringBuilder text = new StringBuilder();
            if (res != null) {
                for (JsonNode block : res.path("content")) {
                    if ("text".equals(block.path("type").asText())) {
                        text.append(block.path("text").asText());
                    }
                }
            }
            String reply = text.toString().trim();
            if (reply.isEmpty()) throw new ApiException(502, "The model returned an empty answer.");
            return reply;
        } catch (RestClientResponseException e) {
            log.warn("Anthropic API error {}: {}", e.getStatusCode().value(), e.getResponseBodyAsString());
            if (e.getStatusCode().value() == 429) {
                throw new ApiException(429, "The AI service is busy. Please try again shortly.");
            }
            throw new ApiException(502, "The AI service returned an error.");
        } catch (RestClientException e) {
            log.warn("Anthropic API unreachable", e);
            throw new ApiException(502, "Could not reach the AI service.");
        }
    }
}
