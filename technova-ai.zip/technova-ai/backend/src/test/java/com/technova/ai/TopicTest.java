package com.technova.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.technova.ai.model.ChatRequest;
import com.technova.ai.model.Topic;
import com.technova.ai.service.ChatService;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class TopicTest {

    @Test
    void unknownTopicFallsBackToGeneral() {
        assertEquals(Topic.GENERAL, Topic.from("nonsense"));
        assertEquals(Topic.GENERAL, Topic.from(null));
        assertEquals(Topic.STOCKS, Topic.from(" stocks "));
    }

    @Test
    void historyIsCleanedSoRolesAlternateAndStartWithUser() {
        ChatService service = new ChatService(null);
        ChatRequest req = new ChatRequest("What next?", "tech", List.of(
                new ChatRequest.Turn("assistant", "stray reply"),
                new ChatRequest.Turn("user", "Hi"),
                new ChatRequest.Turn("assistant", "Hello!"),
                new ChatRequest.Turn("user", "dangling question")));
        List<Map<String, String>> messages = service.buildMessages(req);

        assertEquals(3, messages.size());
        assertEquals("user", messages.get(0).get("role"));
        assertEquals("assistant", messages.get(1).get("role"));
        assertEquals("What next?", messages.get(2).get("content"));
    }
}
