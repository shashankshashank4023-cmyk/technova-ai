# START HERE: from this folder to a live app

Do the steps in order. Each one takes a few minutes.

## 1. Get an API key (free to create)
- Go to https://console.anthropic.com, sign in, create an **API key**, and copy it.
- Add credit and set a **monthly spend limit** so the public site cannot run up a bill.

## 2. Test it on your computer
You need Java 17+ and Maven.
```bash
cd backend
export ANTHROPIC_API_KEY=your-key      # Windows PowerShell: $env:ANTHROPIC_API_KEY="your-key"
mvn test
mvn spring-boot:run
```
Open http://localhost:8080 and ask a question in each topic. If anything fails to compile or run, send me the error.

## 3. Put it on GitHub
Repository name: `technova-ai`
Description: *TechNova AI: an AI assistant for study, tech, politics, banking, stocks, sports and movies. Java Spring Boot backend, installable web app and Android app.*
Topics: `ai-chatbot`, `java`, `spring-boot`, `claude`, `pwa`, `android`

```bash
cd technova-ai          # this folder
git init
git add .
git commit -m "Initial commit: TechNova AI"
git branch -M main
git remote add origin https://github.com/<your-username>/technova-ai.git
git push -u origin main
```
(Never commit your API key. `.gitignore` already blocks `.env`.)

## 4. Deploy the backend (Render, free tier works)
1. https://render.com, then **New → Web Service**, and connect your GitHub repo.
2. Set **Root Directory** to `backend`. Render detects the `Dockerfile`.
3. Under **Environment**, add `ANTHROPIC_API_KEY` = your key.
4. Optional: `WEB_SEARCH_ENABLED=true` for live news, scores and prices (must be enabled in your Anthropic Console).
5. Deploy. Render gives you an HTTPS URL like `https://technova-ai.onrender.com`. Open it and test.

(Free instances sleep when idle, so the first request after a break can take a minute.)

## 5. Use it like an app on phones
With your HTTPS URL:
- **Android (Chrome):** menu (⋮) → **Install app**.
- **iPhone (Safari):** **Share** → **Add to Home Screen**.

## 6. Build the Android app (optional)
Follow `android/README.md`. The key step: set `APP_URL` in `MainActivity.java` to your Render URL, then **Build → Build APK(s)**.

## 7. Update the README
In `backend/README.md` and this README, add your live URL near the top as **Live demo**.

## Checklist
- [ ] API key created, spend limit set
- [ ] Runs locally, tests pass
- [ ] Pushed to GitHub
- [ ] Deployed, live URL works
- [ ] Installed on a phone
- [ ] (Optional) APK built
