# TechNova AI

A multi-topic AI assistant (Study, Tech, Politics, Banking, Stocks, Sports, Movies) with a Java Spring Boot backend, an installable web app (PWA) and an Android app.

| Folder | What it is |
|---|---|
| `backend/` | Java 17 + Spring Boot API and the web frontend. See `backend/README.md` |
| `android/` | Android Studio source for a native app that opens the deployed site. See `android/README.md` |

## Quick start

```bash
cd backend
export ANTHROPIC_API_KEY=your-key
mvn spring-boot:run
```

Open http://localhost:8080. Full deploy and mobile steps are in `START-HERE.md`.

## License

MIT
